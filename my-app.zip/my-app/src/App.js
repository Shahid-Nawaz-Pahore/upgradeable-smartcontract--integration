import { useState } from 'react';
import './App.css';

function App() {
  // State to track the user's wallet address and number
  const [walletAddress, setWalletAddress] = useState(null);
  const [number, setNumber] = useState(null);

  const connectWallet = async () => {
    if (window.ethereum) {
      try {
        const accounts = await window.ethereum.request({
          method: 'eth_requestAccounts',
        });
        setWalletAddress(accounts[0]);
        console.log("Connected wallet address:", accounts[0]);
      } catch (error) {
        console.error("Failed to connect wallet:", error);
  
        // Handle specific MetaMask errors based on their error codes
        if (error.code === 4001) {
          // User rejected the request
          alert("Please connect your wallet to continue.");
        } else if (error.code === -32002) {
          // Request already pending (user needs to unlock MetaMask)
          alert("Wallet connection request is already pending. Please check your wallet.");
        } else {
          // Unknown error
          alert("An unexpected error occurred. Please try again.");
        }
      }
    } else {
      alert("MetaMask is not installed. Please install it to connect your wallet.");
    }
  };
  

  // Placeholder function for setting a number (you'll replace this with actual contract interaction)
  const handleSetNumber = async () => {
    // Here you would typically interact with a smart contract
    console.log("Setting number...");
    setNumber(42); // Example: Setting the number to 42 for demonstration
  };

  // Placeholder function for getting a number (you'll replace this with actual contract interaction)
  const handleGetNumber = async () => {
    // Here you would typically interact with a smart contract to get the number
    console.log("Getting number...");
    const fetchedNumber = 42; // Example fetched number
    setNumber(fetchedNumber);
  };

  return (
    <div className="App">
      <h1>My DApp</h1>
      <p>Wallet Address: {walletAddress || "Not connected"}</p>
      <p>Stored Number: {number !== null ? number : "No number set"}</p>
      <button onClick={connectWallet}>Connect Wallet</button>
      <button onClick={handleSetNumber}>Set Number</button>
      <button onClick={handleGetNumber}>Get Number</button>
    </div>
  );
}

export default App;
